### Hexlet tests and linter status:
[![Actions Status](https://github.com/reyzi26/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/reyzi26/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/c81e6189c284a07bac4e/maintainability)](https://codeclimate.com/github/reyzi26/python-project-49/maintainability)

### step 5 asciinema
[[!Asciinema](https://asciinema.org/connect/1010b710-e886-4423-b479-d6877cfdac91)]

### step 6 asciinema
[![asciicast](https://asciinema.org/a/ltYPqwRm3wS2SYKQv949CXIqr.svg)](https://asciinema.org/a/ltYPqwRm3wS2SYKQv949CXIqr)