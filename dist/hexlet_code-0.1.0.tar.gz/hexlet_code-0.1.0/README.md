### Hexlet tests and linter status:
[![Actions Status](https://github.com/reyzi26/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/reyzi26/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/c81e6189c284a07bac4e/maintainability)](https://codeclimate.com/github/reyzi26/python-project-49/maintainability)